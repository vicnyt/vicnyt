from flask import Flask, request, jsonify
import requests, os

app = Flask(__name__)

@app.route('/')
def home():
    return 'Elite Oddsure API is running!'

@app.route('/stkpush', methods=['POST'])
def stk_push():
    data = request.json
    phone = data.get('phone')
    amount = data.get('amount')
    # Normally you'd call M-Pesa API here
    return jsonify({"message": f"Initiated payment of {amount} to {phone}"})

@app.route('/callback', methods=['POST'])
def callback():
    try:
        body = request.json
        phone = body['Body']['stkCallback']['CallbackMetadata']['Item'][4]['Value']
        amount = body['Body']['stkCallback']['CallbackMetadata']['Item'][0]['Value']
        requests.post("https://eliteoddsure-bot.up.railway.app/send_prediction", json={"phone": phone, "amount": amount})
    except Exception as e:
        print("Callback error:", e)
    return jsonify({"ResultCode": 0, "ResultDesc": "Success"})
