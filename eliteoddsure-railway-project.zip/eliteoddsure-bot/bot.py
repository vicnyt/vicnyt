from flask import Flask, request
import os, requests

app = Flask(__name__)
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ADMIN_ID = os.getenv("ADMIN_ID")

def send_message(chat_id, text):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    requests.post(url, json={"chat_id": chat_id, "text": text})

@app.route('/')
def home():
    return 'Elite Oddsure Bot is running!'

@app.route('/send_prediction', methods=['POST'])
def send_prediction():
    data = request.json
    phone = data.get('phone')
    amount = data.get('amount')
    # Here we simply notify admin (could add user matching)
    send_message(ADMIN_ID, f"Payment received from {phone} of KES {amount}. Prediction sent.")
    return {"status": "ok"}
